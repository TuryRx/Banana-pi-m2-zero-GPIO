#!/bin/bash

sudo patch /usr/lib/python3/dist-packages/gpiozero/pins/data.py gpiozero.patch
